# Changelog

## v1.1
- Overlay en dos líneas: etiqueta **NOW PLAYING** + artista/canción.
- Fondos dinámicos incrementales con clips de 5 minutos (imágenes/vídeos).
- Vídeos convertidos **sin audio** (evita solapes).
- Fade in/out suave en cada clip.
- Regeneración automática de fondos con `systemd timer` (cada 6h por defecto).

## v1.0
- Emisión 24/7 con ffmpeg (logo fijo) + audio Zeno.
- Now playing básico desde Zeno a archivo de texto.
