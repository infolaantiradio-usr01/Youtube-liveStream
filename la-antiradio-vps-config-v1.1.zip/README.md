# La Antiradio YouTube Live Stream (VPS) — v1.1

Este repo contiene los scripts y unidades systemd para emitir **24/7** en YouTube desde un VPS Ubuntu usando:
- Audio: **Zeno.fm** (MP3 128 kbps)
- Vídeo: fondo dinámico (clips de 5 min generados a partir de imágenes/vídeos)
- Overlay: **NOW PLAYING** + artista/canción desde metadatos de Zeno

## 1) Estructura

```
.
├─ README.md
├─ CHANGELOG.md
├─ antiradio-ffmpeg.service
├─ antiradio-nowplaying.service
├─ antiradio-make-backgrounds.service
├─ antiradio-make-backgrounds.timer
└─ antiradio/
   ├─ ffmpeg.sh
   ├─ nowplaying.sh
   └─ make_backgrounds.sh
```

En el VPS todo vive en: **/opt/antiradio**

## 2) Requisitos en Ubuntu

```bash
sudo apt update
sudo apt install -y ffmpeg curl jq fontconfig
```

(El overlay usa la fuente DejaVu, que viene en Ubuntu. Si no, instala `fonts-dejavu`.)

## 3) Carpeta de trabajo

```bash
sudo mkdir -p /opt/antiradio
sudo chown -R root:root /opt/antiradio
```

Copia dentro de `/opt/antiradio`:
- `logo.png` (fallback de carátula y/o logo)
- carpeta `backgrounds/` con tus **imágenes** y **vídeos** (cualquier nombre)

Ejemplo:
```bash
sudo mkdir -p /opt/antiradio/backgrounds
# Sube tus archivos a /opt/antiradio/backgrounds
```

## 4) Generar clips de fondo (5 min) + lista concat

El script genera clips a 720p/30fps y crea/actualiza:
- `/opt/antiradio/bg_clips/*.mp4`
- `/opt/antiradio/bg_concat.txt`

```bash
sudo chmod +x /opt/antiradio/make_backgrounds.sh
sudo /opt/antiradio/make_backgrounds.sh
```

Notas:
- Es **incremental**: si el clip ya existe y el origen no cambió, lo deja como está.
- Los vídeos se exportan **sin audio** para no pisar el audio de la radio.
- Cada clip lleva un **fade in/out** suave (transición más agradable entre cortes).

## 5) Configurar NOW PLAYING (Zeno → nowplaying.txt + cover.jpg)

Edita `/opt/antiradio/nowplaying.sh` si cambias el mount:
- `MOUNT="jkjslxjr7sntv"`

El script escribe:
- `/opt/antiradio/nowplaying.txt`
- `/opt/antiradio/cover.jpg` (si hay imagen; si no, usa `logo.png`)

## 6) Configurar emisión FFmpeg

Edita `/opt/antiradio/ffmpeg.sh` y pon tu key:
- `YOUTUBE_KEY="TU_KEY_AQUI"`

El stream usa:
- 1280x720, 30 fps
- vídeo CBR 2500k (ajustable)
- audio AAC 160k
- overlay: `NOW PLAYING` + contenido de `nowplaying.txt`

## 7) Instalar systemd (servicios 24/7)

Copia las unidades a systemd:

```bash
sudo cp -f antiradio-nowplaying.service /etc/systemd/system/
sudo cp -f antiradio-ffmpeg.service /etc/systemd/system/
sudo cp -f antiradio-make-backgrounds.service /etc/systemd/system/
sudo cp -f antiradio-make-backgrounds.timer /etc/systemd/system/

sudo systemctl daemon-reload
```

Habilitar y arrancar:

```bash
sudo systemctl enable --now antiradio-nowplaying.service
sudo systemctl enable --now antiradio-make-backgrounds.timer
sudo systemctl enable --now antiradio-ffmpeg.service
```

Ver estado/logs:

```bash
systemctl status antiradio-ffmpeg.service --no-pager
journalctl -u antiradio-ffmpeg.service -n 100 --no-pager
```

## 8) Comandos útiles

Parar/arrancar:

```bash
sudo systemctl stop antiradio-ffmpeg.service
sudo systemctl start antiradio-ffmpeg.service
sudo systemctl restart antiradio-ffmpeg.service
```

Reiniciar por si systemd se “bloquea” por muchos reinicios:

```bash
sudo systemctl reset-failed antiradio-ffmpeg.service
sudo systemctl restart antiradio-ffmpeg.service
```

Regenerar fondos manualmente:

```bash
sudo /opt/antiradio/make_backgrounds.sh
sudo systemctl restart antiradio-ffmpeg.service
```

---

## Seguridad

- **No subas tu Stream Key a GitHub.**
- En producción, considera poner la key en un fichero separado (EnvironmentFile) fuera del repo.
