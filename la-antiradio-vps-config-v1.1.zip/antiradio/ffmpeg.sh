#!/usr/bin/env bash
set -euo pipefail

# ====== CONFIG ======
ZENO_URL="https://stream.zeno.fm/jkjslxjr7sntv"
BG_LIST="/opt/antiradio/bg_concat.txt"
NOW_FILE="/opt/antiradio/nowplaying.txt"

# IMPORTANTE: pon aquí tu stream key (NO la subas a GitHub)
YOUTUBE_KEY="TU_KEY_AQUI"
RTMP_URL="rtmp://a.rtmp.youtube.com/live2/${YOUTUBE_KEY}"

FONT="/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"

# Calidad (720p)
VBITRATE="2500k"
ABITRATE="160k"

# ====== FFmpeg ======
exec ffmpeg -hide_banner -loglevel info \
  -thread_queue_size 1024 \
  -reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 10 \
  -i "${ZENO_URL}" \
  -thread_queue_size 1024 \
  -stream_loop -1 -safe 0 -f concat -i "${BG_LIST}" \
  -filter_complex "\
    [1:v]scale=1280:720,format=yuv420p[bg]; \
    [bg]drawtext=fontfile=${FONT}:text='NOW PLAYING': \
      fontcolor=white:fontsize=26: \
      x=40:y=h-110: \
      box=1:boxcolor=black@0.55:boxborderw=14[bg1]; \
    [bg1]drawtext=fontfile=${FONT}:textfile=${NOW_FILE}:reload=1: \
      fontcolor=white:fontsize=34: \
      x=40:y=h-60: \
      box=1:boxcolor=black@0.55:boxborderw=18[v] \
  " \
  -map "[v]" -map 0:a \
  -c:v libx264 -preset veryfast -profile:v high -level 4.1 \
  -r 30 -g 60 -keyint_min 60 -sc_threshold 0 \
  -b:v "${VBITRATE}" -minrate "${VBITRATE}" -maxrate "${VBITRATE}" -bufsize 5000k \
  -pix_fmt yuv420p \
  -c:a aac -b:a "${ABITRATE}" -ar 44100 -ac 2 \
  -flvflags no_duration_filesize \
  -f flv "${RTMP_URL}"
