#!/usr/bin/env bash
set -euo pipefail

# ====== CONFIG ======
MOUNT="jkjslxjr7sntv"
META_URL="https://api.zeno.fm/mounts/metadata/subscribe/${MOUNT}"

DIR="/opt/antiradio"
NOW_FILE="${DIR}/nowplaying.txt"
COVER_FILE="${DIR}/cover.jpg"
LOGO_FILE="${DIR}/logo.png"
LOCAL_COVERS_DIR="${DIR}/covers"

mkdir -p "$LOCAL_COVERS_DIR"

sanitize() {
  # Limpia caracteres raros para texto/nombres de archivo
  echo "$1" | tr -d '\r' | sed 's/[\/:*?"<>|]/_/g; s/  */ /g; s/^ *//; s/ *$//'
}

set_default_cover() {
  # Fallback: usa el logo como carátula si no hay imagen
  cp -f "$LOGO_FILE" "$COVER_FILE"
}

download_cover() {
  local url="$1"
  local tmp="${COVER_FILE}.tmp"
  if curl -fsSL --max-time 15 "$url" -o "$tmp"; then
    mv -f "$tmp" "$COVER_FILE"
    return 0
  fi
  rm -f "$tmp" || true
  return 1
}

extract_image_url() {
  # Zeno no siempre envía imagen, intentamos varios nombres de campo
  jq -r '
    .image? // .imageUrl? // .artwork? // .artworkUrl? // .cover? // .coverUrl? //
    .thumbnail? // .thumbnailUrl? // .albumArt? // .albumArtUrl? // empty
  ' 2>/dev/null || true
}

last_key=""

echo "[nowplaying] leyendo metadatos de: $META_URL"

# Con -N mantenemos streaming SSE sin buffer
curl -fsSL -N "$META_URL" | while IFS= read -r line; do
  [[ "$line" =~ ^data:\  ]] || continue
  json="${line#data: }"

  streamTitle="$(echo "$json" | jq -r '.streamTitle // empty' 2>/dev/null || true)"
  streamTitle="$(echo "$streamTitle" | tr -d '\r')"

  # Presentación: cambiar _ por espacios y limpiar extensiones/sufijos típicos
  pretty="$(echo "$streamTitle" | sed 's/_/ /g')"
  pretty="$(echo "$pretty" | sed -E 's/\s*\(.*\)\.(wav|mp3|flac)$//I; s/\.(wav|mp3|flac)$//I')"
  pretty="$(sanitize "$pretty")"

  if [[ -n "$pretty" ]]; then
    echo "$pretty" > "$NOW_FILE"
  else
    echo "La Antiradio · En directo" > "$NOW_FILE"
  fi

  # Actualizar carátula solo si cambió el tema
  key="$(echo "$pretty" | tr '[:upper:]' '[:lower:]')"
  if [[ -n "$key" && "$key" != "$last_key" ]]; then
    got_cover=0

    # 1) Si Zeno da URL de imagen en JSON
    img_url="$(echo "$json" | extract_image_url)"
    if [[ -n "$img_url" ]]; then
      if download_cover "$img_url"; then
        got_cover=1
      fi
    fi

    # 2) Carátulas locales opcionales: /opt/antiradio/covers/"Artista - Título.jpg"
    if [[ "$got_cover" -eq 0 && -n "$pretty" ]]; then
      local_path="${LOCAL_COVERS_DIR}/${pretty}.jpg"
      if [[ -f "$local_path" ]]; then
        cp -f "$local_path" "$COVER_FILE"
        got_cover=1
      fi
    fi

    # 3) Fallback: logo
    if [[ "$got_cover" -eq 0 ]]; then
      set_default_cover
    fi

    last_key="$key"
  fi
done
